package com.room.sample.servlet;
 
import java.io.IOException;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jboss.as.quickstarts.ejb.remote.stateless.RemoteCalculator;
 
public class CalculatorServlet extends HttpServlet{
 
    private static final long serialVersionUID = 1L;
    public void doPost(HttpServletRequest request, HttpServletResponse response){
        System.out.println("----- Calling EJB Component -----");
        try {
        		System.out.println("Obtained a remote stateless calculator for invocation");
        		int a= Integer.parseInt(request.getParameter("value1"));
        		int b= Integer.parseInt(request.getParameter("value2"));
                RemoteEJBClient(a,b);
	            RequestDispatcher dispatcher=request.getRequestDispatcher("/Result.jsp");
	            dispatcher.forward(request, response);
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }catch(Exception e){
            e.printStackTrace();
        }
         
    }
    
    public void RemoteEJBClient(int a, int b) throws NamingException {
  	  
        Properties env = new Properties();
        env.put(Context.INITIAL_CONTEXT_FACTORY,
                "org.jboss.naming.remote.client.InitialContextFactory");
        env.put(Context.PROVIDER_URL, "http-remoting://localhost:8080");
        env.put(Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming");
        env.put("jboss.naming.client.ejb.context", true);
        InitialContext context = new InitialContext(env);
  
        String ejbJndiName = "EJBCalculator/MyEjbDemo/"
                + "CalculatorBean!org.jboss.as.quickstarts.ejb.remote.stateless.RemoteCalculator";
        final RemoteCalculator statelessRemoteCalculator = (RemoteCalculator) context
                .lookup(ejbJndiName);
        
        System.out.println("Adding " + a + " and " + b + " via the remote stateless calculator deployed on the server");
        int sum = statelessRemoteCalculator.add(a, b);
        System.out.println("calculated Sum : "+sum);
        context.close();
    }
 
}
