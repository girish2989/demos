package org.jboss.as.quickstarts.ejb.remote.stateful;
 
public interface RemoteCounter {
 
    void increment();
 
    void decrement();
 
    int getCount();
}