package org.jboss.as.quickstarts.ejb.remote.stateless;
 
import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.Stateless;
 
@Stateless
@Remote(RemoteCalculator.class)
public class CalculatorBean implements RemoteCalculator {
 
	@EJB(lookup="java:global/EJBMessanger/MyEjbDemo2/MessageBean!org.jboss.as.quickstarts.ejb.remote.stateless.RemoteMessage")
	private RemoteMessage remoteMessage;
	
    @Override
    public int add(int a, int b) {
    	
    	System.out.println("Summation");
    	System.out.println("--->  "+remoteMessage.getMessage());
        return a + b;
    }
 
    @Override
    public int subtract(int a, int b) {
    	System.out.println("Substract");
        return a - b;
    }
}