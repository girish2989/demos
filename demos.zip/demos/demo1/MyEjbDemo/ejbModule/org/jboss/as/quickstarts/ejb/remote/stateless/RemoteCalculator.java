package org.jboss.as.quickstarts.ejb.remote.stateless;

public interface RemoteCalculator {
 
    int add(int a, int b);
 
    int subtract(int a, int b);
}