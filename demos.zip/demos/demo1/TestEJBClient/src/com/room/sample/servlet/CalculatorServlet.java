package com.room.sample.servlet;
 
import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jboss.as.quickstarts.ejb.remote.stateless.RemoteCalculator;
 
public class CalculatorServlet extends HttpServlet{
	
	@EJB(lookup="java:global/EJBCalculator/MyEjbDemo/CalculatorBean!org.jboss.as.quickstarts.ejb.remote.stateless.RemoteCalculator")
	private RemoteCalculator statelessRemoteCalculator;
 
    private static final long serialVersionUID = 1L;
    public void doPost(HttpServletRequest request, HttpServletResponse response){
        System.out.println("----- Calling EJB Component -----");
        try {
        		System.out.println("Obtained a remote stateless calculator for invocation");
                int a = 10;
                int b = 20;
                int sum = statelessRemoteCalculator.add(a, b);
                System.out.println("Resulted sum = " + sum);
	            RequestDispatcher dispatcher=request.getRequestDispatcher("/Result.jsp");
	            dispatcher.forward(request, response);
        } catch (ServletException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }catch(Exception e){
            e.printStackTrace();
        }
         
    }
 
}
