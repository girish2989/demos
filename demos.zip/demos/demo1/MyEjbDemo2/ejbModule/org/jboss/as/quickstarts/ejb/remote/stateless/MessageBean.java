package org.jboss.as.quickstarts.ejb.remote.stateless;

import javax.ejb.Remote;
import javax.ejb.Stateless;

@Stateless
@Remote(RemoteMessage.class)
public class MessageBean implements RemoteMessage {

	@Override
	public String getMessage() {
		return "This is the test message from another ejb";
	}

}
