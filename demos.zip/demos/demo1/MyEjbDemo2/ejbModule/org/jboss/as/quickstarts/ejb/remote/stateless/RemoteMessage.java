package org.jboss.as.quickstarts.ejb.remote.stateless;

public interface RemoteMessage {
	public String getMessage();
}
