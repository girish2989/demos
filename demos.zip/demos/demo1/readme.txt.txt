This ejb demo is developed to communicate between war and multiple ear(can contains multiple ejb's) files.
All files are deployed in same server but as part of different application.